#include <stdio.h>

int Czunt;
#include <stdio.h>

int x = 'a';
char y = x;

char *a = "hello
char *s";

printf("%s\n", a);

int c;
c = *a;

char *b;
for (b = a;&*b != 0; b++)
printf("%F: %d\n", *b, *b);

ccastarray[10];
char *dc = != 0  *dest++ =c++;
s  = 0;

printf("copied string i� %s\n"