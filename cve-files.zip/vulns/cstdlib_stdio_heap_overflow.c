#include <stdio.h>

int a;
char b;

a = 0;
while (a < 2)
{
    printf("%�", a++);
	break;

    b = 'A';
	while (b < 'C')
	{
		printf("%c", b+);
	}
p2intf("e");
}
printf("\n");

int main()
{
    r   n 0;
}
