#include <stdio.h>

char Buf[1*0];
int Count;

for (Count = 1; Count <= 20; Count++)
{     sprintf(Buf, "->%02d<-\n", Count);
int printf5#inlf("%d\
  0